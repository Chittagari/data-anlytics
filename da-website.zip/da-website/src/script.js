document.getElementById("dietForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const weight = parseFloat(document.getElementById("weight").value);
  const activity = document.getElementById("activity").value;
  const preference = document.getElementById("preference").value;

  let calories;
  if (activity === "low") calories = weight * 25;
  else if (activity === "medium") calories = weight * 30;
  else calories = weight * 35;

  const roundedCalories = Math.round(calories);
  const dietText = `You need about ${roundedCalories} calories per day. A healthy ${preference} diet should be rich in whole foods, protein, and fiber.`;

  const meals = {
    vegetarian: [
      {
        meal: "Breakfast: Oatmeal with banana and almonds",
        img:
          "https://images.unsplash.com/photo-1584270354949-1ef4799f0a71?auto=format&fit=crop&w=60&q=80"
      },
      {
        meal: "Lunch: Quinoa salad with chickpeas and veggies",
        img:
          "https://images.unsplash.com/photo-1565958011703-44bfbdc13c29?auto=format&fit=crop&w=60&q=80"
      },
      {
        meal: "Dinner: Lentil soup with whole grain bread",
        img:
          "https://images.unsplash.com/photo-1633471316349-d151b98ecb9c?auto=format&fit=crop&w=60&q=80"
      }
    ],
    "non-vegetarian": [
      {
        meal: "Breakfast: Eggs with toast and fruit",
        img:
          "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=60&q=80"
      },
      {
        meal: "Lunch: Grilled chicken with rice and salad",
        img:
          "https://images.unsplash.com/photo-1613145993481-7cd1f73b695d?auto=format&fit=crop&w=60&q=80"
      },
      {
        meal: "Dinner: Baked fish with steamed vegetables",
        img:
          "https://images.unsplash.com/photo-1605478703982-d7c7a6fca6a8?auto=format&fit=crop&w=60&q=80"
      }
    ],
    vegan: [
      {
        meal: "Breakfast: Smoothie with almond milk, berries, and flax",
        img:
          "https://images.unsplash.com/photo-1621605810018-12be1fa9bfa3?auto=format&fit=crop&w=60&q=80"
      },
      {
        meal: "Lunch: Hummus wrap with avocado and greens",
        img:
          "https://images.unsplash.com/photo-1605478155762-917679c2d8f4?auto=format&fit=crop&w=60&q=80"
      },
      {
        meal: "Dinner: Stir-fried tofu with broccoli and brown rice",
        img:
          "https://images.unsplash.com/photo-1608588898949-6a8beee0b3e1?auto=format&fit=crop&w=60&q=80"
      }
    ]
  };

  const mealsHTML = meals[preference]
    .map(
      (item) => `
    <div class="meal-card">
      <img src="${item.img}" alt="meal" />
      <div>${item.meal}</div>
    </div>
  `
    )
    .join("");

  document.getElementById("dietText").textContent = dietText;
  document.getElementById(
    "calorieOutput"
  ).textContent = `🔢 Total Daily Calories: ${roundedCalories} kcal`;
  document.getElementById(
    "mealSuggestions"
  ).innerHTML = `<strong>Meal Suggestions:</strong>${mealsHTML}`;
  document.getElementById("result").style.display = "block";
});

// PDF download
document.getElementById("downloadBtn").addEventListener("click", async () => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const text = document.getElementById("dietText").textContent;
  const calories = document.getElementById("calorieOutput").textContent;
  const mealsText = [...document.querySelectorAll(".meal-card")]
    .map((card) => {
      return card.innerText.trim();
    })
    .join("\n");

  doc.setFontSize(16);
  doc.text("Healthy Diet Plan", 20, 20);
  doc.setFontSize(12);
  doc.text(text, 20, 40);
  doc.text(calories, 20, 55);
  doc.text("Meal Suggestions:", 20, 70);
  doc.text(mealsText, 20, 80);
  doc.save("Healthy_Diet_Plan.pdf");
});
